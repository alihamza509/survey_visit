@extends('admin.app')

@section('content')
    <!-- Your content goes here -->
    <!-- For example -->
    <section id="dashboard-analytics">
        <div class="row">
 
            </div>
        </div>



    </section>
@endsection
