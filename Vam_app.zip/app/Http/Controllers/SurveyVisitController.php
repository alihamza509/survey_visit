<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\SurveyVisit;
use App\Models\Expense;
use App\Models\FollowUp;
use App\Models\SampleOrder;
use App\Models\TrailOrder;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
class SurveyVisitController extends Controller
{
    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'shop_name' => 'required|unique:survey_visits',
                'owner_name' => 'required',
                'owner_phone' => 'required',
                'owner_email' => 'required|email',
                'geo_location' => 'required',
                'comments' => 'required|string',
                'cement_brands' => 'required|string',
                'other_products' => 'required|string',
                'photo_1' => 'required|image|max:2048',
                'photo_2' => 'required|image|max:2048',
                'photo_3' => 'nullable|image|max:2048',
            ]);
    
            $validatedData['user_id'] = Auth::id();
            if ($request->hasFile('photo_1')) {
                $validatedData['photo_1'] = $request->file('photo_1')->store('photos');
            }
            if ($request->hasFile('photo_2')) {
                $validatedData['photo_2'] = $request->file('photo_2')->store('photos');
            }
            if ($request->hasFile('photo_3')) {
                $validatedData['photo_3'] = $request->file('photo_3')->store('photos');
            }
    
            $surveyVisit = SurveyVisit::create($validatedData);
    
            return response()->json([
                'success' => true,
                'message' => 'Survey visit data stored successfully',
                'data' => $surveyVisit,
            ], 201);
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $e->errors(),
            ], 422);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to store survey visit data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function getShopNames()
    {
        $shops = SurveyVisit::select('id', 'shop_name', 'owner_name', 'owner_phone', 'owner_email', 'geo_location')->distinct()->get();
        
        return response()->json([
            'success' => true,
            'data' => $shops,
        ]);
    }
    public function expenseStore(Request $request)
    {
        $validatedData = $request->validate([
            'date_of_expense' => 'required|date',
            'invoice_photo' => 'required|image|max:2048',
            'expense_detail' => 'required|string',
        ]);

        try {
            $validatedData['user_id'] = Auth::id();
            if ($request->hasFile('invoice_photo')) {
                $validatedData['invoice_photo'] = $request->file('invoice_photo')->store('invoices');
            }

            $expense = Expense::create($validatedData);

            return response()->json([
                'success' => true,
                'message' => 'Expense data stored successfully',
                'data' => $expense,
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to store expense data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function storeSampleOrder(Request $request)
    {
        $validatedData = $request->validate([
            'shop_id' => 'required|exists:survey_visits,id',
            'sample_order' => 'required|string',
            'GST_details' => 'required|string',
            'photo_of_product' => 'required|image|max:2048',
            'comments_of_meeting' => 'required|string',
        ]);

        try {
            $validatedData['user_id'] = Auth::id();
            if ($request->hasFile('photo_of_product')) {
                $validatedData['photo_of_product'] = $request->file('photo_of_product')->store('products');
            }

            $sampleOrder = SampleOrder::create($validatedData);

            return response()->json([
                'success' => true,
                'message' => 'Sample order data stored successfully',
                'data' => $sampleOrder,
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to store sample order data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function indexSampleOrder()
    {
        try {
            $sampleOrders = SampleOrder::all();

            return response()->json([
                'success' => true,
                'data' => $sampleOrders,
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve sample orders',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function storeFollowUp(Request $request)
    {
        $validatedData = $request->validate([
            'shop_id' => 'required|exists:survey_visits,id',
            'photo_display_of_battu' => 'required|image|max:2048',
            'trial_order' => 'required|string',
            'potential_order_horizon' => 'required|date',
            'payment_preference' => 'required',
            'comments_of_meeting' => 'required|string',
        ]);

        try {
            $validatedData['user_id'] = Auth::id();
            
            if ($request->hasFile('photo_display_of_battu')) {
                $validatedData['photo_display_of_battu'] = $request->file('photo_display_of_battu')->store('photos');
            }

            $followUp = FollowUp::create($validatedData);

            return response()->json([
                'success' => true,
                'message' => 'Follow-up stored successfully',
                'data' => $followUp,
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to store follow-up',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Display a listing of the follow-ups.
     *
     * @return \Illuminate\Http\Response
     */
    public function indexFollowUp()
    {
        try {
            $followUps = FollowUp::all();

            return response()->json([
                'success' => true,
                'data' => $followUps,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve follow-ups',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
    public function storeTrailOrder(Request $request)
    {
        $validatedData = $request->validate([
            'shop_id' => 'required|exists:survey_visits,id',
            'photo_display_of_battu' => 'required|image|max:2048',
            'types_of_order' => 'required|string',
            'potential_order_horizon' => 'nullable|date',
            'order_quantity' => 'nullable|integer',
            'order_delivery_calendar' => 'nullable|date',
            'meeting_discussion_summary' => 'required|string',
        ]);

        try {
            $validatedData['user_id'] = Auth::id();

            if ($request->hasFile('photo_display_of_battu')) {
                $validatedData['photo_display_of_battu'] = $request->file('photo_display_of_battu')->store('photos');
            }

            $trailOrder = TrailOrder::create($validatedData);

            return response()->json([
                'success' => true,
                'message' => 'Trail order stored successfully',
                'data' => $trailOrder,
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to store trail order',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function indexTrailOrder()
    {
        try {
            $trailOrders = TrailOrder::all();

            return response()->json([
                'success' => true,
                'data' => $trailOrders,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve trail orders',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
